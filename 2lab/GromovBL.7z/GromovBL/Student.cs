﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace XmlTest
{
    class Student
    {
        public int Id { get; set; }
        public string Nazvanie { get; set; }
        public int Ugl { get; set; }
        public int Belki { get; set; }
        public int Ziri { get; set; }
        public int Cena { get; set; }

        public static IEnumerable<Student> GetAllStudents()
        {
            return new List<Student>
                {
                    new Student{Id = 1, Nazvanie = "Шоколад",   Ugl = 22,         Belki = 3,      Ziri = 13, Cena = 100},
                    new Student{Id = 2, Nazvanie = "Вааауч",    Ugl = 278,        Belki = 5,      Ziri = 42, Cena = 120},
                    new Student{Id = 3, Nazvanie = "Тэсти",     Ugl = 12,         Belki = 10,     Ziri = 28, Cena = 150},
                    new Student{Id = 4, Nazvanie = "Крокодил",  Ugl = 20,         Belki = 25,     Ziri = 10, Cena = 200},
                    new Student{Id = 5, Nazvanie = "Сливки на лбу", Ugl = 38,     Belki = 40,     Ziri = 13, Cena = 350}
            };
        }
    }
}
